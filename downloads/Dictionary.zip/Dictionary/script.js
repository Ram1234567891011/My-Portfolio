async function searchWord() {
  const word = document.getElementById("wordInput").value.trim();
  const resultDiv = document.getElementById("result");

  if (word === "") {
    resultDiv.innerHTML = "<p>Please enter a word.</p>";
    return;
  }

  resultDiv.innerHTML = "<p>Searching...</p>";

  try {
    const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
    const data = await res.json();

    if (data.title === "No Definitions Found") {
      resultDiv.innerHTML = "<p>No definition found. Try another word.</p>";
    } else {
      const entry = data[0];
      const meaning = entry.meanings[0];
      const definition = meaning.definitions[0];
      const phonetic = entry.phonetic || '';
      const audio = entry.phonetics.find(p => p.audio)?.audio || '';

      resultDiv.innerHTML = `
        <h2>${entry.word}</h2>
        <p><strong>Phonetic:</strong> ${phonetic}</p>
        <p><strong>Part of Speech:</strong> ${meaning.partOfSpeech}</p>
        <p><strong>Definition:</strong> ${definition.definition}</p>
        ${definition.example ? `<p><strong>Example:</strong> ${definition.example}</p>` : ""}
        ${audio ? `<audio controls src="${audio}"></audio>` : ""}
      `;
    }
  } catch (error) {
    resultDiv.innerHTML = "<p>Error fetching data. Please try again later.</p>";
  }
}
